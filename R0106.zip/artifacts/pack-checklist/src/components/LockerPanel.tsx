import React, { useState, useEffect } from 'react';
import { PackState, CategoryMeta } from '../hooks/usePackData';
import { Background } from './BackgroundPicker';
import { ChevronDown, ChevronUp, Trash2, FolderOpen, Pencil, Check, X } from 'lucide-react';
import { LockerIcon } from './LockerIcon';
import { SyncStatusPanel, type SyncProps } from './SyncStatusPanel';
import { useBarStyle, barCombinedStyle, barFgStyle, barFontStyle, barCardStyle } from '../context/BarStyleContext';

export type Store = {
  items: PackState;
  order: string[];
  meta: Record<string, CategoryMeta>;
};

export interface LockerEntry {
  id: string;
  name: string;
  savedAt: number;
  store: Store;
  /**
   * Optional for backwards compatibility. Entries created before Photo Lists
   * omit this field and continue to load as standard lists.
   */
  listKind?: 'standard' | 'photo';
  background: Background | null;
  bgFade: number;
  bgTone: 'light' | 'dark';
  /** Fill (cover) vs Fit (contain) mode. Optional for backwards compatibility — older entries
   *  default to 'cover' on load. Added in 021D to preserve the sender's bgSize in shared view. */
  bgSize?: 'cover' | 'contain';
  /** Weight-distribution palette key saved with this file ('trail', 'ocean', etc.).
   *  Optional for backwards compatibility — older entries omit this field. */
  chartPaletteKey?: string;
  /** 023E: Bar/pill background color. Optional for backwards compatibility. */
  barColor?: string;
  /** 023E: Bar/pill font-family. Optional for backwards compatibility. */
  barFont?: string;
  /** 023E: Bar/pill text color. Optional for backwards compatibility. */
  barTextColor?: string;
  /** 023G: Bar/pill background opacity (0 = transparent, 1 = solid). Optional for backwards compatibility. */
  barTransparency?: number;
}

// Re-export for backwards-compat (canonical definition is in usePackData)
export { LOCKER_KEY } from '../hooks/usePackData';

interface LockerPanelProps {
  entries: LockerEntry[];
  onLoad: (entry: LockerEntry) => void;
  /** Called when the user confirms they want to delete an entry.
   *  The parent is responsible for identity verification before deletion. */
  onRequestDelete: (id: string) => void;
  onRename: (id: string, newName: string) => void;
  /** Optional 022T sync diagnostic props. When provided, a SyncStatusPanel is rendered. */
  syncProps?: SyncProps;
  /** 023W: Sidebar Open/Close — when forceOpenSeq increments, panel open/close is set to forceOpen. */
  forceOpen?: boolean | null;
  forceOpenSeq?: number;
  /** 025F: Accordion callback — called after the panel header toggles internal open state. */
  onToggle?: (nowOpen: boolean) => void;
}

function formatDate(ts: number) {
  const d = new Date(ts);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

export function LockerPanel({ entries, onLoad, onRequestDelete, onRename, syncProps, forceOpen, forceOpenSeq, onToggle }: LockerPanelProps) {
  const [open, setOpen] = useState(true);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  // 023W: respond to sidebar Open/Close control
  useEffect(() => {
    if (forceOpen !== null && forceOpen !== undefined) {
      setOpen(forceOpen);
    }
  }, [forceOpen, forceOpenSeq]);
  const [editId, setEditId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [renameError, setRenameError] = useState<string | null>(null);

  const startRename = (entry: LockerEntry) => {
    setEditId(entry.id);
    setEditName(entry.name);
    setRenameError(null);
    setConfirmId(null);
  };

  const confirmRename = () => {
    const trimmed = editName.trim();
    if (!trimmed || !editId) return;
    const isDuplicate = entries.some(e => e.id !== editId && e.name === trimmed);
    if (isDuplicate) {
      setRenameError('A list with this name already exists.');
      return;
    }
    onRename(editId, trimmed);
    setEditId(null);
    setEditName('');
    setRenameError(null);
  };

  const cancelRename = () => {
    setEditId(null);
    setEditName('');
    setRenameError(null);
  };

  const barStyle = useBarStyle();

  // 023F: font cascades to expanded Locker body via outer wrapper
  return (
    <div className="bg-card border border-card-border rounded-xl shadow-sm overflow-hidden" style={{ ...barCardStyle(barStyle), ...barFontStyle(barStyle) }}>
      {/* Header */}
      <button
        onClick={() => { const next = !open; setOpen(next); onToggle?.(next); }}
        className="w-full flex items-center gap-2 p-4 sm:p-5 border-b border-border bg-muted/20 text-left hover:bg-muted/30 transition-colors"
        style={barCombinedStyle(barStyle)}
      >
        {open
          ? <ChevronUp   className="w-4 h-4 text-muted-foreground flex-shrink-0" style={barFgStyle(barStyle)} />
          : <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" style={barFgStyle(barStyle)} />
        }
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 text-foreground" style={barFgStyle(barStyle)}>
            <LockerIcon className="w-4 h-4 flex-shrink-0" />
            <h2 className="font-semibold text-base">Locker</h2>
            {entries.length > 0 && (
              /* 023F: count badge follows text color */
              <span className="text-[10px] font-semibold text-muted-foreground bg-muted px-2 py-0.5 rounded-full" style={barFgStyle(barStyle)}>
                {entries.length}
              </span>
            )}
          </div>
          {/* 023F: description follows text color */}
          <p className="text-xs text-muted-foreground mt-0.5" style={barFgStyle(barStyle)}>
            Your saved gear lists.
          </p>
        </div>
      </button>

      {open && (
        <div style={{ backgroundColor: 'hsl(var(--card))' }}>
          {/* 022T: Sync Status diagnostic panel — shown when signed in */}
          {syncProps && (
            <SyncStatusPanel {...syncProps} localCount={entries.length} />
          )}
          {entries.length === 0 ? (
            <p className="px-5 py-6 text-xs text-muted-foreground text-center">
              No saved lists yet. Click the <strong>Save</strong> button in the toolbar to save the current list.
            </p>
          ) : (
            <div className="divide-y divide-border">
              {entries.map(entry => (
                <div key={entry.id} className="px-4 py-3 hover:bg-muted/20 transition-colors group">
                  {editId === entry.id ? (
                    /* ── Rename mode ── */
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center gap-1.5">
                        <input
                          autoFocus
                          type="text"
                          value={editName}
                          onChange={e => { setEditName(e.target.value); setRenameError(null); }}
                          onKeyDown={e => {
                            if (e.key === 'Enter') confirmRename();
                            if (e.key === 'Escape') cancelRename();
                          }}
                          maxLength={40}
                          className="flex-1 text-xs border border-border rounded-md px-2 py-1.5 bg-background focus:outline-none focus:border-primary/50 text-foreground placeholder:text-muted-foreground min-w-0"
                        />
                        <button
                          onClick={confirmRename}
                          disabled={!editName.trim()}
                          title="Confirm rename"
                          className="p-1.5 rounded hover:bg-primary/10 text-primary disabled:opacity-40 transition-colors flex-shrink-0"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={cancelRename}
                          title="Cancel rename"
                          className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      {renameError && (
                        <p className="text-[10px] text-destructive pl-0.5">{renameError}</p>
                      )}
                    </div>
                  ) : confirmId === entry.id ? (
                    /* ── Delete confirm mode ── */
                    <div className="flex items-center gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{entry.name}</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">{formatDate(entry.savedAt)}</p>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <span className="text-[10px] text-destructive font-medium hidden sm:inline">Delete?</span>
                        <button
                          onClick={() => { onRequestDelete(entry.id); setConfirmId(null); }}
                          className="text-[10px] font-semibold bg-destructive text-destructive-foreground px-2 py-1 rounded"
                        >
                          Yes
                        </button>
                        <button
                          onClick={() => setConfirmId(null)}
                          className="text-[10px] font-semibold bg-muted text-muted-foreground px-2 py-1 rounded"
                        >
                          No
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* ── Normal mode ── */
                    <div className="flex items-center gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{entry.name}</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">{formatDate(entry.savedAt)}</p>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0 opacity-60 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => onLoad(entry)}
                          title="Load this list in a new tab"
                          className="p-1.5 rounded hover:bg-primary/10 text-muted-foreground hover:text-primary transition-colors"
                        >
                          <FolderOpen className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => startRename(entry)}
                          title="Rename"
                          className="p-1.5 rounded hover:bg-primary/10 text-muted-foreground hover:text-primary transition-colors"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setConfirmId(entry.id)}
                          title="Delete"
                          className="p-1.5 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
